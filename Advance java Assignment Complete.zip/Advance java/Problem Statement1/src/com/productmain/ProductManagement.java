/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.productmain;

import com.fpt.nhatnk.pms.ui.ProductConsole;

/**
 *
 * @author Nhat
 */
public class ProductManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProductConsole pc = new ProductConsole();
        pc.start();
    }
    
}
