package com.mphasis.practice;

import java.util.Scanner;

public class Book {
	private String book_title;
	private String book_price;
	
	
	
	public String getBook_title() {
		return book_title;
	}
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	public String getBook_price() {
		return book_price;
	}
	public void setBook_price(String book_price) {
		this.book_price = book_price;
	}
	
	
	
	public Book(String book_title, String book_price) {
		super();
		this.book_title = book_title;
		this.book_price = book_price;
	}
	public void createBooks() {
		
	}
	public void showBooks() {
		
		
		System.out.println(""+book_title+"\t"+book_price);
		
		
	}
}
