package com.mphasis.practice;

public class BookDetails {

	public static void main(String[] args) {
	
		Book[] book= new Book[2];
		
		book[0]=new Book("Java Programimng","RS 350.50");
		book[1]=new Book("Let Us C","RS 200.00 ");

		System.out.println(" Book Title\t\tBook Price \n");;  
		book[0].showBooks();  
		  
		book[1].showBooks(); 
		
		
	}

}
