package com.mphasis.practice;

public class Rectangle {
	private double length;
	private double breadth;
	
	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getBreadth() {
		return breadth;
	}

	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}


	
	public double AreaofRectangle()
	{
		double Area;
		System.out.println("Length "+getLength());
		System.out.println("Breath "+getBreadth());
		Area=length * breadth;
		System.out.println("Area "+Area);
		System.out.println("\n");
		return 0;
		
	}
	    
}


