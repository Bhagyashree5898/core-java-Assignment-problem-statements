
public class Rectangle {
	private double length=1;
	private double breadth=1;
	
	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		if (length > 0 && length < 20)
		  {
		   this.length = length;
		  }
	}

	public double getBreadth() {
		return breadth;
	}

	public void setBreadth(double breadth) {
		if (breadth > 0 && breadth < 20)
		  {
		   this.breadth = breadth;
		  }
	}


	
	public void AreaofRectangle()
	{
		
		double Area;
		double Perimeter;
		System.out.println("Length "+getLength());
		System.out.println("Breath "+getBreadth());
		Area=length * breadth;
		System.out.println("Area "+Area);
		Perimeter= 2 * (getLength() +getBreadth());
		System.out.println("Perimeter "+Perimeter);
		System.out.println("\n");
		
		
	}

}
