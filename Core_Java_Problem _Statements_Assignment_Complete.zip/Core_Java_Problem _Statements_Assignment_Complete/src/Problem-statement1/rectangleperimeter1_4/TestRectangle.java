
public class TestRectangle {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(10,20);
		Rectangle r2 = new Rectangle(10,5);
		Rectangle r3 = new Rectangle(12,9);
		Rectangle r4 = new Rectangle(30,2);
		Rectangle r5 = new Rectangle(10,7);
		
		r1.AreaofRectangle();
		r2.AreaofRectangle();
		r3.AreaofRectangle();
		r4.AreaofRectangle();
		r5.AreaofRectangle();

	}

}
