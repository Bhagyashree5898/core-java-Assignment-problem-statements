package com.mphasis.practice;

import java.util.Arrays;

public class ArrayEx {

	public static void main(String[] args) {
		int A[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		int sum = 0;
		for (int i = 0; i<=(A.length-3);i++)
		{
			sum=sum+A[i];
		}
		System.out.println("Sum of first 14 number is "+sum);	
		A[15]=sum;
		
		int avg=0;
		int sum1=0; 
		for (int i = 0; i<=(A.length-2);i++)
		{
			sum1+=A[i];
			avg=sum1/(A.length-2);
		}
		System.out.println("Average of first 15 number is "+avg);
		A[16]=avg;
		
		 
		{
			int from=0;
			int end= 16;
			Arrays.sort(A, from, end);
			System.out.println("Smallest value in array is "+A[0]);
			A[17]=A[0];
		}
		
	};

}
