package com.mphasis.practice;

public class Flute extends Instrument {

	@Override
	public void Play() {
		System.out.println("Flute is playing toot toot toot toot");
	}

}
