package com.mphasis.practice;

public abstract class Instrument {
	
	public abstract void Play();
}

