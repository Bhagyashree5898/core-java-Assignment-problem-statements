package com.mphasis.practice;

public class InstrumentMain {
	
	public static void main(String[] args) {
		Instrument a[] = new Instrument[10];
		a[0] = new Piano();
		a[1] = new Flute();
		a[2] = new Guitar();
		a[3] = new Piano();
		a[4] = new Flute();
		a[5] = new Guitar();
		a[6] = new Piano();
		a[7] = new Flute();
		a[8] = new Guitar();
		a[9] = new Piano();
		
	for ( int i = 0 ; i < a.length ; i++ )
	{
		if ( a[i] instanceof Piano )
		{
			System.out.println("Yes, Its Piano");
			a[i].Play();
		}
		if ( a[i] instanceof Flute )
		{
			System.out.println("Yes, Its Flute");
			a[i].Play();
		}
		if ( a[i] instanceof Guitar )
		{
			System.out.println("Yes, Its Guitar");
			a[i].Play();
		}
	}
}
}
