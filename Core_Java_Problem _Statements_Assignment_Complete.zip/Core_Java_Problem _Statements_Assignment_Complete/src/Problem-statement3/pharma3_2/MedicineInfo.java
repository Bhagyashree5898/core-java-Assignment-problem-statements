package com.mphasis.practice;

public class MedicineInfo {
	public void displayLabel()
	{
	System.out.println("Company : Globel Pharma");
	System.out.println("Address : Pune");
	}
}
