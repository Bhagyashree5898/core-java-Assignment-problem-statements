package com.mphasis.practice;

public class Ointment extends MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("for external use only");
	}

}
