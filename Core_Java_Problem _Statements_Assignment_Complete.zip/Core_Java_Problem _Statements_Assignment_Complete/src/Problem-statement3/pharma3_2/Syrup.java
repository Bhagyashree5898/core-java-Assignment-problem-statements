package com.mphasis.practice;

public class Syrup extends MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("Consumption as directed by thephysician");
	}

}
