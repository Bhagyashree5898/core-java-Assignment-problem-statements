package com.mphasis.practice;

public class Tablet extends MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("store in a cool dry place");
	}

}
